package uta.cse3310;

public class Statistics {
    int xwins;
    int owins;
    int draws;
    int gplayed;
    int currentg;
}
